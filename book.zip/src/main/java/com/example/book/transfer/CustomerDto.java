package com.example.book.transfer;

import lombok.Data;

@Data
public class CustomerDto {

    private Long customerId;

    private Long bookId;
}
